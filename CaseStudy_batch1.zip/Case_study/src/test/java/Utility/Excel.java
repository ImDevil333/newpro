package Utility;

import java.io.FileInputStream;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class Excel extends constants{
	
	
	public static void ReadExcel() throws Exception {
		FileInputStream fs = new FileInputStream("C:\\Users\\tarun\\eclipse-workspace\\Case_study\\Data\\Book11.xlsx");
		@SuppressWarnings("resource")
		XSSFWorkbook workbook = new XSSFWorkbook(fs);
		XSSFSheet sheet = workbook.getSheetAt(0);
		Row row1 = sheet.getRow(1);
		Cell cell = row1.getCell(0);
		Cell cell1 = row1.getCell(1);
		Cell cell2 = row1.getCell(2);
		Cell cell3 = row1.getCell(3);
		Cell cell4 = row1.getCell(4);
		Cell cell5 = row1.getCell(5);
		Cell cell6 =row1.getCell(6);
		Cell cell7 =row1.getCell(7);
		Cell cell8 =row1.getCell(8);
		Cell cell9 =row1.getCell(9);
		Cell cell10 =row1.getCell(10);
		Cell cell11=row1.getCell(11);

		cellval = cell.getStringCellValue();
		cellval1 = cell1.getStringCellValue();
		cellval2 = cell2.getStringCellValue();
		cellval3 = cell3.getStringCellValue();
		cellval4 = cell4.getStringCellValue();
		cellval5= (long)cell5.getNumericCellValue()+"";
		cellval6=(long) cell6.getNumericCellValue()+"";
		cellval7 = cell7.getStringCellValue();
		cellval8 = cell8.getStringCellValue();
		cellval9= (long)cell9.getNumericCellValue()+"";
		cellval10= (long)cell10.getNumericCellValue()+"";
		cellval11 = cell11.getStringCellValue();
	}

}
