package Utility;

import reader.FileHelper;
import reader.PropertiesReader;

public class constants {

	public static PropertiesReader propertiesReader = new PropertiesReader();
	public static String url=propertiesReader.fetchURL();
	public static String ProductName=propertiesReader.fetchProductName();
	public static String ExpMonth=propertiesReader.fetchMonth();
	public static String ExpYear=propertiesReader.fetchYear();
	public static String PO_Num=propertiesReader.fetchPO_number();
	public static String OutputFile=FileHelper.getBasePath()+"\\Output\\OrderDetails.txt";
	public static String ScreenShotPath=FileHelper.getBasePath()+"\\Output\\PaymentError.png";
	public static String Reports=FileHelper.getBasePath()+"\\extent.html";
	public static String Compare_ScreenShot=FileHelper.getBasePath()+"\\Output\\Compare.png";
	protected static String cellval;
	protected static String cellval1;
	protected static String cellval2;
	protected static String cellval3;
	protected static String cellval4;
	protected static String cellval5;
	protected static String cellval6;
	protected static String cellval7;
	protected static String cellval8;
	protected static String cellval9;
	protected static String cellval10;
	protected static String cellval11;
}
