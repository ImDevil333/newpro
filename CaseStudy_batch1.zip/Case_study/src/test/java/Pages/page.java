package Pages;

import java.awt.Desktop;
import java.io.File;
import java.io.PrintWriter;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import reader.PropertiesReader;
import Utility.Excel;
import Utility.constants;

public class page extends constants{


	public static WebDriver driver;

	static PropertiesReader propertiesReader = new PropertiesReader();
	
	By Search_B=By.id("small-searchterms");
	By Search_b=By.xpath("//input[@class='button-1 search-box-button']");
	By CheapComp_product=By.xpath("//a[text()='Build your own cheap computer']");
	By ExpenComp_product=By.xpath("//a[text()='Build your own expensive computer']");
	By AddToCart_b=By.xpath("//input[@value='Add to cart']");
	By ShoppingCart=By.xpath("//span[text()='Shopping cart']");
	By CartQuantity=By.xpath("//span[@class='cart-qty']");
	By RemoveCart_C=By.xpath("//input[@name='removefromcart']");
	By UpdateCart_b=By.xpath("//input[@name='updatecart']");
	By Compare_b=By.xpath("//input[@value='Add to compare list']");
	By TermsofService_C=By.id("termsofservice");
	By Checkout_b=By.id("checkout");
	By CheckoutAsGuest_b=By.xpath("//input[@value='Checkout as Guest']");
	By FirstName_B=By.id("BillingNewAddress_FirstName");
	By LastName_B=By.id("BillingNewAddress_LastName");
	By Email_B=By.id("BillingNewAddress_Email");
	By CountryID_D=By.id("BillingNewAddress_CountryId");
	By City_B=By.id("BillingNewAddress_City");
	By Address_B=By.id("BillingNewAddress_Address1");
	By PostCode_B=By.id("BillingNewAddress_ZipPostalCode");
	By PhoneNumber_B=By.id("BillingNewAddress_PhoneNumber");
	By Continue_BillingAddress=By.xpath("//input[@onclick='Billing.save()']");
	By Continue_ShippingAddress=By.xpath("//input[@onclick='Shipping.save()']");
	By Continue_ShippingMethod=By.xpath("//input[@onclick='ShippingMethod.save()']");
	By COD_R=By.id("paymentmethod_0");
	By MoneyOrder_R=By.id("paymentmethod_1");
	By CreditCard_R=By.id("paymentmethod_2");
	By CreditCard_type=By.id("CreditCardType");
	By Card_name=By.id("CardholderName");
	By Card_number=By.id("CardNumber");
	By Expire_mon=By.id("ExpireMonth");
	By Expire_year=By.id("ExpireYear");
	By CardCode=By.id("CardCode");
	By PurchaseOrder_R=By.id("paymentmethod_3");
	By Continue_PaymentMethod=By.xpath("//input[@onclick='PaymentMethod.save()']");
	By Continue_PaymentInfo=By.xpath("//input[@onclick='PaymentInfo.save()']");
	By Order_details=By.id("checkout-confirm-order-load");
	By Continue_ConfirmOrder=By.xpath("//input[@onclick='ConfirmOrder.save()']");
	By BillingInfo=By.xpath("//ul[@class='billing-info']");
	By shippingInfo=By.xpath("//ul[@class='shipping-info']");
	By TotalInfo=By.xpath("//div[@class='total-info']");
	By validation_msg=By.xpath("//div[@class='validation-summary-errors']");
	WebDriverWait wait;





	public page(WebDriver d){
		driver=d;

	}

	public void OpenUrl(){
	
		driver.get(url);
		driver.manage().window().maximize();
		wait=new WebDriverWait(driver, Duration.ofSeconds(10));
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	}


	public void AddItemToCart() throws InterruptedException {
		driver.findElement(Search_B).click();
		driver.findElement(Search_B).sendKeys(ProductName);
		driver.findElement(Search_b).click();
		driver.findElement(CheapComp_product).click();
		driver.findElement(AddToCart_b).click();

		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,0)");
		Thread.sleep(2000);
		driver.findElement(ShoppingCart).click();
		//		String Items=driver.findElement(CartQuantity).getText();
		//		System.out.println("No.of Items in cart: "+Items);

	}

	public void RemoveItemFromCart() {
		driver.findElement(RemoveCart_C).click();
		driver.findElement(UpdateCart_b).click();
		//		String Items=driver.findElement(CartQuantity).getText();
		//		System.out.println("No.of Items in cart: "+Items);

	}

	public void CompareTwoItems() throws Exception {

		driver.navigate().to(url);
		driver.findElement(CheapComp_product).click();
		driver.findElement(Compare_b).click();
		driver.navigate().to(url);
		driver.findElement(ExpenComp_product).click();
		driver.findElement(Compare_b).click();
		Takescreenshot(Compare_ScreenShot);

	}
	

	public void CheckoutAsGuestUser() {
		driver.findElement(TermsofService_C).click();
		driver.findElement(Checkout_b).click();
		driver.findElement(CheckoutAsGuest_b).click();

	}

	public void PaymentProcessing() throws Exception {

		Excel.ReadExcel();
		driver.findElement(FirstName_B).sendKeys(Excel.cellval);
		driver.findElement(LastName_B).sendKeys(Excel.cellval1);
		driver.findElement(Email_B).sendKeys(Excel.cellval2);
		WebElement Country=driver.findElement(CountryID_D);
		Select select1=new Select(Country);
		select1.selectByVisibleText(Excel.cellval11);
		driver.findElement(City_B).sendKeys(Excel.cellval3);
		driver.findElement(Address_B).sendKeys(Excel.cellval4);
		driver.findElement(PostCode_B).sendKeys(Excel.cellval5);
		driver.findElement(PhoneNumber_B).sendKeys(Excel.cellval6);
		Continue();
	}
	
	public void Continue() {
		
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_BillingAddress)));
		driver.findElement(Continue_BillingAddress).click();
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_ShippingAddress)));
		driver.findElement(Continue_ShippingAddress).click();
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_ShippingMethod)));
		driver.findElement(Continue_ShippingMethod).click();

	}
	
	public void MoneyOrder() {
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(MoneyOrder_R))).click();
	}
	
	public void PurchaseOrder() {
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(PurchaseOrder_R))).click();
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_PaymentMethod)));
		driver.findElement(Continue_PaymentMethod).click();
		wait.until(ExpectedConditions.visibilityOf(driver.findElement(PurchaseOrder_R)));
		driver.findElement(PurchaseOrder_R).sendKeys(PO_Num);
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_PaymentInfo)));
		driver.findElement(Continue_PaymentInfo).click();
		String billInfo=driver.findElement(BillingInfo).getText();
		String ShippingInfo=driver.findElement(shippingInfo).getText();
		String totalInfo=driver.findElement(TotalInfo).getText();
		System.out.println(billInfo+ShippingInfo+totalInfo);
	}
	
	public void GotoCart() {
		driver.findElement(ShoppingCart).click();
	}

	public void OrderDetails() throws Exception {

		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_PaymentMethod)));
		driver.findElement(Continue_PaymentMethod).click();
		wait.until(ExpectedConditions.elementToBeClickable(driver.findElement(Continue_PaymentInfo)));
		driver.findElement(Continue_PaymentInfo).click();
		String billInfo=driver.findElement(BillingInfo).getText();
		String ShippingInfo=driver.findElement(shippingInfo).getText();
		String totalInfo=driver.findElement(TotalInfo).getText();
//		System.out.println(billInfo+ShippingInfo+totalInfo);
		File myfile=new File(OutputFile);
		myfile.createNewFile();
		PrintWriter mw=new PrintWriter(myfile);
		mw.println(billInfo+ShippingInfo+totalInfo);
		mw.close();
	}

	public void InvalidPaymentOption() throws Exception {
		Excel.ReadExcel();
		driver.findElement(CreditCard_R).click();
		driver.findElement(Continue_PaymentMethod).click();
		WebElement CreditType=driver.findElement(CreditCard_type);
		Select select2=new Select(CreditType);
		select2.selectByVisibleText(Excel.cellval7);
		driver.findElement(Card_name).sendKeys(Excel.cellval8);
		driver.findElement(Card_number).sendKeys(Excel.cellval9);
		WebElement ExpireMonth=driver.findElement(Expire_mon);
		Select select3=new Select(ExpireMonth);
		select3.selectByVisibleText(ExpMonth);
		WebElement ExpireYear=driver.findElement(Expire_year);
		Select select4=new Select(ExpireYear);
		select4.selectByVisibleText(ExpYear);
		driver.findElement(CardCode).sendKeys(Excel.cellval10);
		driver.findElement(Continue_PaymentInfo).click();
		Thread.sleep(1000);
		Takescreenshot(ScreenShotPath);
		String error_msg=driver.findElement(validation_msg).getText();
		System.out.println("Payment Cannot be processed because: "+error_msg);

	}

	public void Takescreenshot(String path) throws Exception {
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		File trg=new File(path);
		FileUtils.copyFile(src, trg);
	}

	public void flush() throws Exception {
		driver.quit();
		Desktop.getDesktop().browse(new File(Reports).toURI());
	}










}
