package TestScenario;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import Pages.page;
import Utility.constants;
import base.BrowserHandler;

public class PageTest extends BrowserHandler {

	page p;
	WebDriver driver;
	ExtentHtmlReporter htmlReporter;
	ExtentReports extent;
	BrowserHandler browserHandler = new BrowserHandler();

	@BeforeTest()

	public void initialiseSetUp()  {
		htmlReporter =new ExtentHtmlReporter("extent.html");
		extent=new ExtentReports();
		extent.attachReporter(htmlReporter);
		
		driver = BrowserHandler.getDriver();
		p=new page(driver);
		p.OpenUrl();
	}

	@Test(priority=1)
	public void TestCase_1() throws Exception {

		ExtentTest test1=extent.createTest("FirstTest","Search and Add to Cart");
		test1.log(Status.INFO,"Test is starting");
		
		p.AddItemToCart();
		
		test1.pass("Item is added to cart");

	}


	@Test(priority=2)
	public void TestCase_2() throws Exception {

		ExtentTest test2=extent.createTest("SecondTest","Remove Item from cart, Compare Items");
		test2.log(Status.INFO,"Test is starting");
		
		p.RemoveItemFromCart();
		p.CompareTwoItems();
		
		test2.pass("Item is removed from cart and Two Items are compared");

	}
	@Test(priority=3)
	public void TestCase_3() throws Exception{

		ExtentTest test3=extent.createTest("ThirdTest","CheckOut using Guest USer");
		test3.log(Status.INFO,"Test is starting");
		
		p.AddItemToCart();
		p.CheckoutAsGuestUser();
		
		test3.pass("CheckedOutAs GuestUser")	;	

	}
	@Test(priority=4)
	public void TestCase_4() throws Exception{

		ExtentTest test4=extent.createTest("FourthTest","Payment Processing");
		test4.log(Status.INFO,"Test is starting");
		
		//		p.AddItemToCart();
		//		p.CheckoutAsGuestUser();
		
		p.PaymentProcessing();
		
		test4.pass("payment is processing");


	}
	@Test(priority=5)
	public void TestCase_5() throws Exception {

		ExtentTest test5=extent.createTest("FifthTest","Printing order details in External File");
		test5.log(Status.INFO,"Test is starting");
		
		//		p.AddItemToCart();
		//		p.CheckoutAsGuestUser();
		//		p.PaymentProcessing();
		
		p.OrderDetails();
		
		test5.pass("Order details printed successfully");

	}
	@Test(priority=6)
	public void TestCase_6() throws Exception {


		ExtentTest test6=extent.createTest("SixthTest","Providing Invaild payment options and capturing validation Error");
		test6.log(Status.INFO,"Test is starting");
		
		p.GotoCart();
		p.CheckoutAsGuestUser();
		p.Continue();
		p.InvalidPaymentOption();

		test6.addScreenCaptureFromPath(constants.ScreenShotPath);
		test6.pass("Error has been captured");


	}

	@AfterTest

	public void TearDown() throws Exception {

		extent.flush();

		p.flush();
	}


}
