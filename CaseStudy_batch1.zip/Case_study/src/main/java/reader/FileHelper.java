package reader;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class FileHelper {
	/**
	 * fetching base path of the project
	 * 
	 * @return
	 */
	public static String getBasePath() {
		return System.getProperty("user.dir");
	}

	/**
	 * get config properties file location
	 * 
	 * @return
	 */
	public String getMainResourceConfig() {
		return getBasePath() + "/src/main/resources/config.properties";
	}

	/**
	 * Return config file in binaries
	 * 
	 * @return
	 * @throws FileNotFoundException
	 */
	public InputStream getConfigFile() throws FileNotFoundException {
		// System.out.println(getMainResourceConfig());
		return new FileInputStream(getMainResourceConfig());
	}

}
