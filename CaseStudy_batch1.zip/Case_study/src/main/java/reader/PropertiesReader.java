package reader;

import java.io.IOException;
import java.util.Properties;

public class PropertiesReader {

	private static Properties prop;

	public PropertiesReader() {
		FileHelper fileHelper = new FileHelper();
		prop = new Properties();
		try {
			prop.load(fileHelper.getConfigFile());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	// Getting browser name from user
	public String fetchBrowserName() {
		return prop.getProperty("browser");
	}
	public String fetchProductName() {
		return prop.getProperty("product");
	}
	public String fetchURL() {
		return prop.getProperty("URL");
	}
	public String fetchMonth() {
		return prop.getProperty("ExpireMonth");
	}
	public String fetchYear() {
		return prop.getProperty("ExpireYear");
	}

	public String fetchPO_number() {
		return prop.getProperty("PO_Number");
	}
}
