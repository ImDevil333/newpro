package base;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import reader.PropertiesReader;

public class BrowserHandler {
	public static WebDriver driver;
	static PropertiesReader propertiesReader = new PropertiesReader();

	/**
	 * handling different browsers (ex:Chrome & Firefox & Edge)
	 * 
	 * @return
	 */
	public static WebDriver getDriver() {
		String browserName = propertiesReader.fetchBrowserName();
		System.out.println("Browser defined in properties file: " + browserName);
		switch (browserName) {
		case "Chrome":
			// System.out.println("You have chosen Chrome Browser");
			//WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver();
			break;
		case "Firefox":
			// System.out.println("You have chosen Firefox Browser");
			
			driver = new FirefoxDriver();
			break;
		case "Edge":
			// System.out.println("You have chosen Edge Browser")
			driver = new EdgeDriver();
			break;
		default:
			System.out.println("The browser name is not same as defined.");
			break;
		}
		return driver;
	}
}
